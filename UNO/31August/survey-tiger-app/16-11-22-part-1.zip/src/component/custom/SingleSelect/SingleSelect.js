import './SingleSelect.css';


const SingleSelect=()=>{
    return (<div>Single Select file</div>)
}
export default SingleSelect;