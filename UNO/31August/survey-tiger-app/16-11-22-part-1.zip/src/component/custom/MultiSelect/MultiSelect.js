import './MultiSelect.css';

const MultiSelect=()=>{
        return (<div>
            multiselect
        </div>)
}
export default MultiSelect;