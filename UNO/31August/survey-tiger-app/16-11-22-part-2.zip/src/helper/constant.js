export const QuestionTypeLabel={
    single_type:'single-select',
    multi_type:'multi-select'
};

export const EmployeeType={
      fullName:"string"
};